from setuptools import setup, find_packages

setup(
    name="predictive_market_analysis",
    version="0.0.3",
    packages=find_packages(include=['predictive_market_analysis', 'predictive_market_analysis.*']),
    install_requires=[],
)
